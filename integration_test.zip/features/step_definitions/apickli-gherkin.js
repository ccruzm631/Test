
const prettyJson = require('prettyjson');
const {Before, Given, When, Then} = require('cucumber');

const jsonPath = require('JSONPath');
const crypto = require('crypto');
const constants = require('constants');
var parametersGlobal = [];


const stepContext = {};

const prettyPrintJson = function(json) {
    const output = {
        stepContext,
        testOutput: json,
    };

    return prettyJson.render(output, {
        noColor: true,
    });
};

const callbackWithAssertion = function(callback, assertion) {
    if (assertion.success) {
        callback();
    } else {
        callback(prettyPrintJson(assertion));
    }
};

Before(function(scenarioResult, callback) {
    // https://github.com/cucumber/cucumber-js/issues/891
    // stepContext.step = step.getName;
    // stepContext.scenario = scenario.getName;

    callback();
});

Given(/^I set (.*) header to (.*)$/, function(headerName, headerValue, callback) {
    this.apickli.addRequestHeader(headerName, headerValue);
    callback();
});

Given(/^I set cookie to (.*)$/, function(cookie, callback) {
    this.apickli.addCookie(cookie);
    callback();
});

Given(/^I set headers to$/, function(headers, callback) {
    this.apickli.setHeaders(headers.hashes());
    callback();
});

Given(/^I set body to (.*)$/, function(bodyValue, callback) {
    this.apickli.setRequestBody(bodyValue);
    callback();
});

Given(/^I pipe contents of file (.*) to body$/, function(file, callback) {
    this.apickli.pipeFileContentsToRequestBody(file, function(error) {
        if (error) {
            callback(new Error(error));
        }

        callback();
    });
});

Given(/^I set query parameters to$/, function(queryParameters, callback) {
    this.apickli.setQueryParameters(queryParameters.hashes());
    callback();
});

Given(/^I set form parameters to$/, function(formParameters, callback) {
    this.apickli.setFormParameters(formParameters.hashes());
    callback();
});

Given(/^I have basic authentication credentials (.*) and (.*)$/, function(username, password, callback) {
    this.apickli.addHttpBasicAuthorizationHeader(username, password);
    callback();
});

Given(/^I have (.+) client TLS configuration$/, function(configurationName, callback) {
    this.apickli.setClientTLSConfiguration(configurationName, function(error) {
        if (error) {
            callback(new Error(error));
        }
        callback();
    });
});
/** Cambios para consumir api Seguridad**/
Given(/^Yo envio (.*) al header como (.*)$/, function(headerName, headerParam, callback) {
    const headerValue = this.apickli.getGlobalVariable(headerParam);
    this.apickli.addRequestHeader(headerName, headerValue);
    callback();
});
Given(/^Yo requiero encryptar los parametros (.*)$/, function(parametersName, callback) {
    var newObj = parametersName.substring(1, parametersName.length-1);
    parametersGlobal = [];
    if (newObj.indexOf(',') > 1) {
        parametersGlobal = newObj.split(',');
    } else {
        parametersGlobal.push(newObj);
    }
    callback();
});
Given(/^Yo con la llave (.*) preparo un body (.*)$/, function(globalkey, bodyValue, callback) {
    const publicKey = this.apickli.getGlobalVariable(globalkey);

    for (var index = 0; index<parametersGlobal.length; index++) {
        if (bodyValue.includes(parametersGlobal[index].trimStart())) {
            bodyValue = findParameter(bodyValue, parametersGlobal[index], publicKey);
        }
    }
    this.apickli.setRequestBody(bodyValue);
    callback();
});
/** Funciones para cifrar los campos en listados previamente  y que requiere una llave pública**/
function findParameter(bodyTxt, paramName, pubKeyValue) {
    var pubKeyValue = "-----BEGIN PUBLIC KEY-----\n" + pubKeyValue + "\n-----END PUBLIC KEY-----";
    var objJSON = JSON.parse(bodyTxt);

    for (let i in objJSON) {
        if (i == paramName.trimStart()) {
            objJSON[i] = encryptValue(JSON.stringify(objJSON[i]), pubKeyValue);
            //break;//Quitar para el caso de que el campo se repita
        } else if (objJSON[i] instanceof Object) {
            findNodeValue(objJSON[i], paramName, pubKeyValue);
        }
    }
  return JSON.stringify(objJSON);
};
function findNodeValue(jsonNode, key, pubKey) {
    for (let j in jsonNode) {
        console.log(jsonNode[j])
        if (j == key.trimStart()) {
            jsonNode[j] = encryptValue(JSON.stringify(jsonNode[j]), pubKey);
            return 0;
        } else if (jsonNode[j] instanceof Object) {
            return findNodeValue(jsonNode[j], key, pubKey);
        }
    }
};

function encryptValue(paramValue, pubKey) {
    var buffer = Buffer.from(paramValue, 'utf8');
    var encrypted = crypto.publicEncrypt({key:pubKey, padding : crypto.constants.RSA_PKCS1_PADDING}, buffer);
    return encrypted.toString("base64");
};
/**Terminan funciones de encriptado **/



When(/^I GET (.*)$/, function(resource, callback) {
    this.apickli.get(resource, function(error, response) {
        if (error) {
            callback(new Error(error));
        }

        callback();
    });
});

When(/^I POST to (.*)$/, function(resource, callback) {
    this.apickli.post(resource, function(error, response) {
        if (error) {
            callback(new Error(error));
        }

        callback();
    });
});

When(/^I PUT (.*)$/, function(resource, callback) {
    this.apickli.put(resource, function(error, response) {
        if (error) {
            callback(new Error(error));
        }

        callback();
    });
});

When(/^I DELETE (.*)$/, function(resource, callback) {
    this.apickli.delete(resource, function(error, response) {
        if (error) {
            callback(new Error(error));
        }

        callback();
    });
});

When(/^I PATCH (.*)$/, function(resource, callback) {
    this.apickli.patch(resource, function(error, response) {
        if (error) {
            callback(new Error(error));
        }

        callback();
    });
});

When(/^I request OPTIONS for (.*)$/, function(resource, callback) {
    this.apickli.options(resource, function(error, response) {
        if (error) {
            callback(new Error(error));
        }

        callback();
    });
});
/**Funciones Then para descifrar parámetros de respuesta recibiendo: el nombre de la llave privada, campo JSON y valor a compara (en claro o expresión regular) */
Then(/^al desencriptar con llave (.*) el campo respuesta (.*) debe ser (((?!of type).*))$/, function(globalkey, path, value, callback) {
    const prvKey = "-----BEGIN PRIVATE KEY-----\n" +  this.apickli.getGlobalVariable(globalkey) + "\n-----END PRIVATE KEY-----";
    
    path = this.apickli.replaceVariables(path);
    const contentType = this.apickli.getResponseObject().body;
    const headers = this.apickli.getResponseObject().headers;
    const contentJson = JSON.parse(contentType);
    const evalResult = jsonPath({resultType: 'all'}, path, contentJson);
    var rest = evalResult[0].value;

    var msg = new Buffer.from(rest, 'base64');
    var descryptValue = crypto.privateDecrypt({key:prvKey, padding : crypto.constants.RSA_PKCS1_PADDING}, msg);
    var strValue = descryptValue.toString().split("\"").join("");

    const regExpObject = new RegExp(value);
    const successExp = regExpObject.test(strValue);
        
    const assertion = getAssertionResultado(successExp, strValue, value, contentType, headers);
     
    callbackWithAssertion(callback, assertion);
});
const getAssertionResultado = function(success, expected, actual, contentBody, headers) {
    return {
        success,
        expected,
        actual,
        response: {
            statusCode: 400,
            headers: headers,
            body: contentBody,
        },
    };
};


Then(/^response header (.*) should exist$/, function(header, callback) {
    const assertion = this.apickli.assertResponseContainsHeader(header);
    callbackWithAssertion(callback, assertion);
});

Then(/^response header (.*) should not exist$/, function(header, callback) {
    const assertion = this.apickli.assertResponseContainsHeader(header);
    assertion.success = !assertion.success;
    callbackWithAssertion(callback, assertion);
});

Then(/^response body should be valid (xml|json)$/, function(contentType, callback) {
    const assertion = this.apickli.assertResponseBodyContentType(contentType);
    callbackWithAssertion(callback, assertion);
});

Then(/^response code should be (.*)$/, function(responseCode, callback) {
    const assertion = this.apickli.assertResponseCode(responseCode);
    callbackWithAssertion(callback, assertion);
});

Then(/^response code should not be (.*)$/, function(responseCode, callback) {
    const assertion = this.apickli.assertResponseCode(responseCode);
    assertion.success = !assertion.success;
    callbackWithAssertion(callback, assertion);
});

Then(/^response header (.*) should be (.*)$/, function(header, expression, callback) {
    const assertion = this.apickli.assertHeaderValue(header, expression);
    callbackWithAssertion(callback, assertion);
});

Then(/^response header (.*) should not be (.*)$/, function(header, expression, callback) {
    const assertion = this.apickli.assertHeaderValue(header, expression);
    assertion.success = !assertion.success;
    callbackWithAssertion(callback, assertion);
});

Then(/^response body should contain (.*)$/, function(expression, callback) {
    const assertion = this.apickli.assertResponseBodyContainsExpression(expression);
    callbackWithAssertion(callback, assertion);
});

Then(/^response body should not contain (.*)$/, function(expression, callback) {
    const assertion = this.apickli.assertResponseBodyContainsExpression(expression);
    assertion.success = !assertion.success;
    callbackWithAssertion(callback, assertion);
});

Then(/^response body path (.*) should be (((?!of type).*))$/, function(path, value, callback) {
    const assertion = this.apickli.assertPathInResponseBodyMatchesExpression(path, value);
    callbackWithAssertion(callback, assertion);
});

Then(/^response body path (.*) should not be (((?!of type).+))$/, function(path, value, callback) {
    const assertion = this.apickli.assertPathInResponseBodyMatchesExpression(path, value);
    assertion.success = !assertion.success;
    callbackWithAssertion(callback, assertion);
});

Then(/^response body path (.*) should be of type array$/, function(path, callback) {
    const assertion = this.apickli.assertPathIsArray(path);
    callbackWithAssertion(callback, assertion);
});

Then(/^response body path (.*) should be of type array with length (.*)$/, function(path, length, callback) {
    const assertion = this.apickli.assertPathIsArrayWithLength(path, length);
    callbackWithAssertion(callback, assertion);
});

Then(/^response body should be valid according to schema file (.*)$/, function(schemaFile, callback) {
    this.apickli.validateResponseWithSchema(schemaFile, function(assertion) {
        callbackWithAssertion(callback, assertion);
    });
});

Then(/^response body should be valid according to openapi description (.*) in file (.*)$/, function(definitionName, swaggerSpecFile, callback) {
    this.apickli.validateResponseWithSwaggerSpecDefinition(definitionName, swaggerSpecFile, function(assertion) {
        callbackWithAssertion(callback, assertion);
    });
});

Then(/^I store the value of body path (.*) as access token$/, function(path, callback) {
    this.apickli.setAccessTokenFromResponseBodyPath(path);
    callback();
});

When(/^I set bearer token$/, function(callback) {
    this.apickli.setBearerToken();
    callback();
});

Given(/^I store the raw value (.*) as (.*) in scenario scope$/, function(value, variable, callback) {
    this.apickli.storeValueInScenarioScope(variable, value);
    callback();
});

Then(/^I store the value of response header (.*) as (.*) in global scope$/, function(headerName, variableName, callback) {
    this.apickli.storeValueOfHeaderInGlobalScope(headerName, variableName);
    callback();
});

Then(/^I store the value of body path (.*) as (.*) in global scope$/, function(path, variableName, callback) {
    this.apickli.storeValueOfResponseBodyPathInGlobalScope(path, variableName);
    callback();
});

Then(/^I store the value of response header (.*) as (.*) in scenario scope$/, function(name, variable, callback) {
    this.apickli.storeValueOfHeaderInScenarioScope(name, variable);
    callback();
});

Then(/^I store the value of body path (.*) as (.*) in scenario scope$/, function(path, variable, callback) {
    this.apickli.storeValueOfResponseBodyPathInScenarioScope(path, variable);
    callback();
});

Then(/^value of scenario variable (.*) should be (.*)$/, function(variableName, variableValue, callback) {
    if (this.apickli.assertScenarioVariableValue(variableName, variableValue)) {
        callback();
    } else {
        callback(new Error('value of variable ' + variableName + ' isn\'t equal to ' + variableValue));
    }
});