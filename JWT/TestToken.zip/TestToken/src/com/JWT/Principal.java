package com.JWT;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.RSAPrivateCrtKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Date;
import java.util.Iterator;

import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPPrivateKey;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPPublicKeyRing;
import org.bouncycastle.openpgp.PGPPublicKeyRingCollection;
import org.bouncycastle.openpgp.PGPSecretKey;
import org.bouncycastle.openpgp.PGPSecretKeyRing;
import org.bouncycastle.openpgp.PGPSecretKeyRingCollection;
import org.bouncycastle.openpgp.PGPUtil;
import org.bouncycastle.openpgp.jcajce.JcaPGPPublicKeyRingCollection;
import org.bouncycastle.openpgp.operator.jcajce.JcaKeyFingerprintCalculator;
import org.bouncycastle.openpgp.operator.jcajce.JcaPGPKeyConverter;
import org.bouncycastle.openpgp.operator.jcajce.JcePBESecretKeyDecryptorBuilder;

import com.sun.xml.internal.fastinfoset.Decoder;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

public class Principal {

	// private static File publicKeyFile = new
	// File("src/carl_0xD32EFE47_public.asc");
	// private static File privateKeyFile = new File("src/0x68008CC7-sec.asc");
	private static String pkString = "xcMGBF9uDz0BCAC3rTxYDSopq5m0ldJaZQ27vSNd+dqrqGCiWmoz+qfEb0ivHWsiy0+xb6PzJ2Km+eurDafUR7q1hm673cwJXWrDzo4SgDKpNxp5Wnqh7j05syyilsr6ru7tQDN6oOS/Q9JwZmlhZGjxdEqq1xI/05jeZowVbotAbv7qD4VpI/MkpM9EewZp6nrf73+aFHHXvuYlKbj9crKfDybimAOSM+RwWPH5VdOB7HJXsMLR+YGYcMI3bPskJx5w3V4xK3IyPsTlC9AUGtyt6Gv/srT7osLTxEzUBsUDXa0RqjQiGu/HK9YWzrNSjsIObZI9XPU16BZoal3zRNQVf6Ha4AxpsPgzABEBAAH+CQMIva4DW97ammlgBG2iM23HAspYLJvNMdM2eH2ZCXIb78tggSdXOjpQZInGWhRzNF1Hvkr2nGEjBtuHiIxTdizwHtENeebVFnellCyin6AlilVXY/8OEMNyPPKz8eRLF+uVQPHsKTKyUVefptVwlwA++eAYBffkyvATihsYqVqBZyh5Qd+2fFKYIiGRg//Gc0ND/vnpSojCCzJ9INSGB5vju1Q8XyS0s1BFflPga8dfBGlw01PyZDkyeEK/bc8jB3pr4gKTCoqEP5myO8afoXiV51Whea4aNwiCIpkA255KTHgWceDC9pVKssFpjsly/+ty9kKAHmTKaNAJUy8FTSQtwUud04X3dhl3JdwQ5jX2J9B4RqjRevlTVYtYPPQiktStBq7ilxhLX6VMRgfc6nH7BheRj/fVDooKjd0JwyJdsw6yQRnJ2jeJVASDHTabse7KmESLNmfMDrTwdE2fZXIipCzZInpVb5vbpYOTpQ9Z78hxumcmh2lt/os/4+ps+jywcW/dT9T+xLukYsvUXAJsCg8AjIBQFWmcpTcFNDFfuDkOKuTKJhPjwNeYUHc501NT0Upiaq2cM4LkyvdaEdbbKyH6QuaaztTkfiaoA95FroiKVZPcEFkTvOhk1x/VH3JGKqNJE6RfvO66uqp5Z6Q47bkITP+Pi/LjB6hM+hDGjZsGq9PjkpsclD/oNC6rwQQG2OOpY4gwdzhlqSYp/n/LsnitO4wtustkOu6cC3CeWqUZsMZmnjJaeOB32u0hOvl0P79ohrPgnDbBfqSH8GIg5p9zF7+rSIpdW7iTjS3zLXJ7q3zVd3yR2JdSlUhMnL++WrFKaYCwsxxwpo1x/Dzn1633myyGB78hy2ry5O3802Fyvuvd/LAXzALIWOkxhUH9PYCuTcZh9Iw1dMj+7FCZsMeMdMrPzRRjYXJsIDxjYXJsQGluZm8uY29tPsLAbQQTAQoAFwUCX24PPQIbLwMLCQcDFQoIAh4BAheAAAoJELu+AK1oAIzHpOgH/Rygpte8cJF0P7m26NRTYoAp8UfiBNE7IFP+f1rmaP4Sqhme9Y4ZC9xB5SbSfyo31MWV8Rk2rqf4n8HmxnXU0gn/l0o3xbGNYwgt5P/h04lkXCyNgaQeyJ91AhbClYvCfMzGrCsVb/VT3FiJAP8Tt/xwBJqOIAapu2sl2zHAGdqirgzDBoWRyym8mRmNA//yB0siIcYk1W/umIx00IUAQzmWzDAGN2uVJ6sm451DZlikG4ZSAkficzOt6BzFQ7lbgkCHHlGmn6gX3/OquUzLuLE5wJYhlGfR4ZEo1RNXwH2qrQwSCRzwORrG+saB6/eS3+MjdX4qx4C1KM9wTBui7HnHwwUEX24PPQEIALnIpQjKRbfli3eiRU/5BxW5+qb28+Ob9zLJTH+ZRplaw59jwSz8CdkezuWMTjxxNbSF0dw7feZlXWef1hv+EncwALrqj94swq7gShfk8pxwKe92AhC9DwsTjXEoOG/vz/XE2eGWI/wkEZ9yjs2kb/P1pwvUFujdt4uBYNBxNoFrm7FMDPfrkmMrTQWsvAWv8IaTQ9gZ0sN6oQlKWbr2WOB5kC8+2HfwR++fVg/JlOhH3HvHQPiqwTOGVryRxsTBp+feWIQR/c/VapMDeY/QKHHIYHPbE+7u0HlgHWCUjIHNW240W6D4X+1jpC/BObHs7es1e6iV6C7OK7+sFvq9Aj0AEQEAAf4JAwiGr1Qn7PV5e2DFSrrYv/WxwGDnzdOqH4hGTXWNSp+M+CIa+hswxP/NOj4aQTttMWpgaX+KDaE6icE4UXs+cGNP6qGqhlIJfb/xod6LmuT+dKqyNVNAZOet9F78/BjPpe8f1mKdyHGySJG+Pt1mnxZGZibCISCjLwMffVPh58ei6jJyxwaTK0VocwMKodxShXmR9rgYkCMN9SFBnyJw3xWK8C2zDsNoFB8deX5FrP6rxXVmzuYmlI39Uh9+Oey+JmbbjDr8+VjfyCJU0J7HNH0KrsIDRTkM5rwmgEQHahZFwGrwTfuR0uY0xl0P7E7kgUGOmaUeunO03TzLR1BKdM3YuXzG4FNgJ+md5yPr8yIxqOHYLB5e7IFmprA5dNFpXHJj2p5kP/Z1uGH6ea6v3J+9/WqfKQj4shK/yp407Nmw51BKAbk9YExZfn3nfhC7AVX1F/FzJcUYJaFoUT0LhVAh0HIJVZH4b1qRtnQP+zEfyGvNQ6ij1TXByOmToL0EQAj17yDyEQBbd0DfycXnxy+KypzsWOLaV2feYyRnK5sploRPA2Pr50NWSJXyFbPmXR2U2mMSl2BPd/cgjxMbE94PCiOhY3PqSNlTMivwJQqXZSpKyWlmVavYEGRSL4ugAL60+JPVSQ/y3fi9pRX81O4Nq7qQEyVEfmAbTLTn+92kkPNKYc5JeqqNjhGDWlVzX4bUFJbJRS1Itz6EcXyVIg5/AdaxDcPVtgXuSe4FDVkvD5w5vQehIwXF8iori8bqKU/gpRESA9ectCuPgSFyLa/UVGlW5bjyDAMEu8VoSEmuqEWJrUhmioWNH7VyBxXbU2o9ye4DHADq6AfqYRdULbwn1MCbtC8HfavfiGCtuOQPyu/X001VGCiou3fuNVi6EfZ25acEyDKztV5aZpwyWit8/bTgzsLBhAQYAQoADwUCX24PPQUJDwmcAAIbLgEpCRC7vgCtaACMx8BdIAQZAQoABgUCX24PPQAKCRA9EguRFX+GMFh0B/oCQ0JIzeJ14BlEEQl/mpyqDc5CeNzguTct7v7+++TXUpmCvczNNGYD925HajnegqJTX8aQBt9uLPtm7Z+XYbN+/dwNeyMj1eLVqVsBjRq70xn1hwShYye3RLA5NkeTQBJyi/40oKCBRK6tBW5XN73WMZfMRquqIaqm5RCEToSEFX6kn+9zes6gxQJR2x9GPv9XQr7b7Wlrgc501ZT5EGnMQoLy2lHJaNIp9DR55C16RS+/Pc06ko5w1mHJ8/gsIiw9Mk9WTLqtM7imnoXJEKSLS08DQDx7gDJazahFGA7nZ0/rLI6SF1QXFD1/mzbNmoin6FXn6ZlMfs325sCstEe6RmwH+QHSOhvP31iBXxw5B5N1fk23naoMxVCUddDnWbOImAmHcZPOZlKxkxtjK8huAcxCbMgp6S8UIu1w/AOrX/bovgT4Bjru5c5A61a9JYys5/uyVTnDGgYc4lEuXEK7/BVIYxx6nApY1yJjekVUqKZ3TEBuK/wLWS38h3wgGHCb0F4JHHTmjRfVSV0EyE/AD4p+2vRXeAEYkseYtRoQ9Zkvub37HqXlxiixPK08bsVVYFdoD7QsVr1pF1IB3EaVA5aDUgVdQgLdmPvBVQnyKLq/J1vogSsTqSzLeqg93hamw1PEQjGvYHjRUSvuewA95UgtITcu/wS+jxMNlzFitlJyBWLHwwYEX24PPQEIAL0BD8Vy7lPijqIE43axYYNJPoHUQvy+9NpfkSG+NWrHOmc/h4wkU+MB/QW+89lhu24YXs7ZcdgEmcEKQdx/Ww9XIFWjQsJfSPBab7gpwkD55UKlVnm6uPQRlTO6y/jgq3WFSMF9QD09MzggIi1rLdTjWHg8hvsGk46TfFrlKxHXwMe9JfMeJ2UuytNq9JdwlnfOig7RCpnxUiot9IRtDScDTCwYNbrjyGh4KUcPUbPoHIGBYvS4rrEPfgMFvnkd8HTLchaYRu0wRPWfeT/D+XaajRb6rWZLIVmEfdT9c/TGd/90b64kzaN0qh5yI2aSmpOIEmbXgPfrEtRNlXmdIqMAEQEAAf4JAwjjAMCjlqpRamCbfCav1Hho6z9jzDzsveGEmGbKVZOHlKmOLgb7Ml1vql1RO02zElGmOrcWHdnEzXNC7CeVrfbvfT/+2fHkGOwj5qK/IENJFqXddrYAmZKvR4QpAggD5EnS5AICmbEtmRlNjILFcvLsLEx6HNxjoZQje1Ge5kqnjbuLUXYLFDnL34uuBwctATncQy5J9HXMYg3LiyJ6rAtlk9FEucOEGcnEuMSsjN1YzO3Yh2g7tX/Xslt96B/QP5/ziftfz3/KNhs4Esa1Pck7nFYKuDZnrNVX2DL5wb4A/N4cZb62Xb809FeV/K4lsh/pClsiDmjNwd1NT4Fv8ssoAbV4+8Y3feq2rDc2sLWg2GkZFVTZk5pIejoYV2mESuK5smnkoyf9N5p6lnpiXjIy5GsUbyPAHU28M6DLpIMfssiMj9xXsNS4g2I1wwFY3RK5mBwBwdpBcPmBnsM/Djd+CN6swpnxD0+zxI8T8X7w7jqYSYvWVgb58JFJYdZmPs2TZyUhDldHPIZRxNeEQqy97dngE8pqCvZadMLRP4Emp8/mxqdSTrELXOg7PPwKeTOfkr8NnXpmPjGSeIx1q/y9lj6nZVNHjZWJj8Z+GvhENf7JzzMcLaY3vtebF+vvmzEZRovRDHSb2cb8sF/cQWq8OSKSfNDYNwUQuWGxqs8gdmy6CpVUnmbd7s3v2q79eR3uen6bpEm3IhJNG3jKCJgLbv+8fgSEEoS7PWBmt4kLb2r3JPBkBsEsqZpNG5Hos9k3rSAMA0AULSfp544gRfbpDP8mLJtkViRhv9r+HPCqGwFGnTkA41bkGfi9ZSFaOIVj4qeFgX8Vedv5b5RGEIXWXX3n0Lgz0snpgWnQiVzawlLHgS1WIN7EZ2kid8UHWYbQoq66wJFayDXTUsqfG/6ZaeCNWETCwYQEGAEKAA8FAl9uDz0FCQ8JnAACGy4BKQkQu74ArWgAjMfAXSAEGQEKAAYFAl9uDz0ACgkQUVzhPJ7cMqeLhQgAvFt4qNl/vM4jci95O6p0dfVZ1SAjnOFF9i1MZ+zgXeSzvfezo78XZdVWyIGzqzy+qT40YKKEeZQV7YMVO7NcdlYcwZ3fDlIw47YUxJdYhyTzFRNzy3EU8rNWcJy9eABFUYoi/T2OuiXGocJD26nztzaaj/vpeC6Kole0+a+9wGHaET+7zb3f7NF8IVk3EBb2CwbvcV4rXOracwcJEw1CAfKwOJ6b/ud9Oxyr1LhJOfSwBAIUNK1NDIB+vw/lOMFrxLXShUG3VmQUxRX+sQV1JaPtZjLs54HYHovBbAFn2a5gB2T8ikdCKtt550w+qe2KKkclBTX3BuwElHAxS01jNPeQCAC03FpMF8Lva+Frl6J10wJ1r2swzXw7PGrvXLVo/roLU+rBQggcF68FOSAtCoAIPnyfz7kowMf3Fpdt9DtaAVFjj1+wk+AB1UjqkboKdgBvjm0TuuRMNJv/YsmYr+YePFgtBbMG8SCJYLs4j+slDCBJbExJRnsZLLHRdjS3yZQFiUmYqfLmI2k8v1i3Su+YW894ajxlIlYODLlfkgDEfqXfbzYNoCdFZnx6cTTtOrNZ5SO6OEpI0cSdczjAZQHtg6Zi0qSHyXipsWY9RX0eacMe+WeP+WGlL/gLboQeFey+n3aek2OLvRlBW3OlZ/4cUG1LFwpngD4XyZvzdtUEv1As=Gqt5";

	public static void main(String[] args) {

		try {
			// PGPPublicKey keyPub = Principal.readPublicKey(new
			// FileInputStream(publicKeyFile));

			// PrivateKey keyPriv = readPrivateKey(new FileInputStream(privateKeyFile));
			// System.out.println("key: " + keyPriv);

			PrivateKey keyPriv = createPrivateKey(pkString);
			try {
				// String tk1 = Principal.createTokenHMAC(keyPub.toString(), "Apigee02",
				// "charly", "Test", 8000);

				// System.out.println("token HMAC: " + tk1);

				String tk2 = Principal.createTokenRSA(keyPriv);

				System.out.println("token RSA: " + tk2);

			} catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
				e.printStackTrace();
			}

		} catch (IOException | PGPException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}

	}

	
	public static PrivateKey readPrivateKey(InputStream input)
			throws IOException, PGPException, NoSuchProviderException {
		final PGPSecretKeyRingCollection pgpSec = new PGPSecretKeyRingCollection(PGPUtil.getDecoderStream(input),
				new JcaKeyFingerprintCalculator());
		Iterator<?> rIt = pgpSec.getKeyRings();

		while (rIt.hasNext()) {
			PGPSecretKeyRing kRing = (PGPSecretKeyRing) rIt.next();
			Iterator<?> kIt = kRing.getSecretKeys();

			while (kIt.hasNext()) {
				PGPSecretKey k = (PGPSecretKey) kIt.next();

				if (k != null) {
					String pass = "password";
					PGPPrivateKey pk = k
							.extractPrivateKey(new JcePBESecretKeyDecryptorBuilder().build(pass.toCharArray()));
					return new JcaPGPKeyConverter().getPrivateKey(pk);
				}
			}
		}

		throw new IllegalArgumentException("Can't find secured key in key ring.");
	}

	
	@SuppressWarnings("resource")
	public static PrivateKey createPrivateKey(String strPk) throws IOException, PGPException {
		InputStream input = new ByteArrayInputStream(strPk.getBytes());
		input = PGPUtil.getDecoderStream(input);

		final PGPSecretKeyRingCollection pgpSec = new PGPSecretKeyRingCollection(PGPUtil.getDecoderStream(input),
				new JcaKeyFingerprintCalculator());

		Iterator<?> rIt = pgpSec.getKeyRings();
		input.close();
		while (rIt.hasNext()) {
			PGPSecretKeyRing kRing = (PGPSecretKeyRing) rIt.next();
			Iterator<?> kIt = kRing.getSecretKeys();

			while (kIt.hasNext()) {
				PGPSecretKey k = (PGPSecretKey) kIt.next();

				if (k != null) {
					String pass = "password";
					PGPPrivateKey pk = k
							.extractPrivateKey(new JcePBESecretKeyDecryptorBuilder().build(pass.toCharArray()));
					return new JcaPGPKeyConverter().getPrivateKey(pk);
				}
			}
		}
		throw new IllegalArgumentException("Can't find secured key in key ring.");
	}
	
	/**
	 * Method for create the object with private key.
	 * @param key
	 * @return String token
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeySpecException
	 */
	public static String createTokenRSA(PrivateKey key)
			throws NoSuchAlgorithmException, InvalidKeySpecException {
		String retStr = null;

		try {
			KeyFactory kf = KeyFactory.getInstance("RSA");
			PKCS8EncodedKeySpec spec = kf.getKeySpec(key, PKCS8EncodedKeySpec.class);

			PrivateKey privKey = kf.generatePrivate(spec);

			retStr = Jwts.builder()
					.setHeaderParam("typ", "JWT")
					.claim("sub", "Isaias")
					.setIssuedAt(new Date())
					.setExpiration(new Date(System.currentTimeMillis() + (60 * 60 * 1000)))
					.signWith(SignatureAlgorithm.RS256, privKey).compact();

		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (InvalidKeySpecException e) {
			e.printStackTrace();
		}

		return retStr;
	}

}
